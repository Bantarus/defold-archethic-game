return {



casual_player = {
	difficulty = "hard",
	score = 0
},



}